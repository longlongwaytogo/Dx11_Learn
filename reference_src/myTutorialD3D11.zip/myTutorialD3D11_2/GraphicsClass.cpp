#include "GraphicsClass.h"


GraphicsClass::GraphicsClass(void)
	{
	}

GraphicsClass::GraphicsClass(const GraphicsClass&)
	{

	}
GraphicsClass::~GraphicsClass(void)
	{
	}

bool GraphicsClass:: Initialize(int screenWidth, int screenHeight, HWND hwnd)
	{

	return true;
	}

void GraphicsClass::Shutdown()
	{

	return;
	}


bool GraphicsClass::Frame()
	{

	return true;
	}


bool GraphicsClass::Render()
	{

	return true;
	}